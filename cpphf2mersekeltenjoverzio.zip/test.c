#pragma once

// (BOM)[]
// (asddasdasd)

intel
4.4; // " asd 5 "

// 1.1f,2
"" \t ""

m[s*16+o]

			for (o = 0; o < 16; o++) {
				if (o == 8) fprintf(fp, " ");
				if (s*16+o < size)
					fprintf(fp, "%02x ", m[s*16+o]);
				else
					fprintf(fp, "   ");
			}
			fprintf(fp, " ");
			for (o = 0; o < 16; o++) {
				if (s*16+o < size)
					fprintf(fp, "%c", isprint(m[s*16+o]) ? m[s*16+o] : '.');
				else

const char const* arr = "float int auto " "auto auto"  1.0f "asd" ("int 5") "double" "register" register
"1.1f 4 4 5 6 [2] 1.0f 1022.103,5,6.0f"

int* a = NULL;
NULL;NULL;
NULL

if(a!=NULL && a ! =    NULL) "NULL";

#include <stdio.h>
#include <stdbool.h>
#include "mmm.hpp"

#define lol "letdafunbegin"
#define lol2 3.14159265395 // pi

typedef struct x
{
   char% ll;
   Node* a;
   char* b;
   int n;	
};

10;
10.0;
10.0f;

sizeof((double)10.0f +2.22+(float)1);

new;
delete;

bool lowerThan10(int a)
{
	return (float)a<(double)10;	    
}


//COMMMENT SHOULD BE LIGHT GRAY!!!!!!!!!

// int  long long int unsigned auto 10 4.4

/* basic 
* multiline
* comment
* without
* keywords*/

/* fake multiline comment =) */

/* auto multiline
	register comment
	 	int with char
			return keywords */

"MULTILINE COMMENT VS STRING/* "asda
asdasdd
asdd
adsad*/

/* eddig ko/*mment */ itt m�r nem int */

int /*
	random comm
auto *************** * / ent*/ doublechar double;char;auto;

#ifdef lol

int main()
{
	double pi = 3.141592654;
	float fpi=3.1415f ;

	bool a = pi<10;
	bool b = 5.5<(double)3.3f;
	bool c = 5 == 10	;				

	const char* str = "...";
	const char* sss="---,,,\t\n";

	//foreach
	//eachfor

	for(unsigned long long int i = 0; i < 15; ++i)	//  long long is 0
	{
		if(lowerThan10(i) == true)
		{
			//...
		}
	} 
}

#endif